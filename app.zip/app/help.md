# Main Header
## Sub Header 1
### Sub Header 2
#### Sub Header 3
##### Sub Header 4

Paragraphs are separated by a blank line.
Normal text.

if you want to break the next line put two spaces before the newline character.  
New line

This is how you make a text **bold**.  
This is how you make a text *italic*.  
This is how you make a text ~~strike through~~.  
This is how you make a text [link](http://google.com "google").  
This is how you embed a image  
![](http://via.placeholder.com/150 "google").

This is how you make list
* List Item 1
* List Item 2
  *	List Item 2.1
      * List Item 2.1.1
          * List Item 2.1.1.1
            
This is how to make a table

| Column1 | Column2 | Column3 |
|:---:|:---|---:|
| This column is center aligned | This column is left aligned | This column is right alight |
| This column is center aligned | This column is left aligned | This column is right alight |
| This column is center aligned | This column is left aligned | This column is right alight |

.

---
This is how you make a horizontal line

This is how you embed inline code. ex:  `bootstrap` class.

Below is how you embed code 
```csharp
protected void Page_Load(test,test){
}
```

```sql
Select * from Table1 where T=2
```

```typescript
import {CoolStuf} from '/module/CoolStuff'
export class SomeClass{
}
```

```powershell
Get-Item 'path to the Item' 
```

```xml
<XmlRoot id="root">
  <child>Test</child>
</XmlRoot>
```

```html
<div id="root">
  <span>Test</span>
</div>
```

```json
{
  Content:[
    {
      Name:"Rudy",
      Age:21
    },
    {
      Name:"Judy",
      Age:24
    }
  ],
  {
    Status:"Field"
  }
}
```  